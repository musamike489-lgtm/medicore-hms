# 🏥 Rijong MediCore HMS

A professional **Hospital Management System** Android app built with WebView + HTML/CSS/JavaScript.

---

## 📱 Features

### 🔐 Security
- 4-digit PIN lock screen on every launch
- Change PIN anytime from the login screen
- Manual lock button in the top bar

### 🏠 Dashboard
- Live stats: admitted patients, critical, discharged, revenue
- Ward occupancy chart (Cardiology, Orthopedics, Neurology, General, ICU, etc.)
- Today's appointment schedule
- Recent patients list
- Revenue summary with collection progress bar

### 👥 Patients
- Full patient records: name, age, gender, blood type, ward, doctor, diagnosis
- Status badges: Admitted, Critical, Discharged
- Add, edit, delete patients
- Search by name, ward, or diagnosis

### 🩺 Doctors
- Doctor profiles: specialty, experience, schedule, email, phone
- Live patient count (counts from current patient records)
- Status: On Duty / Off Duty
- Add, edit, delete doctors

### 📅 Appointments
- Schedule appointments with date, time, room, type
- Status: Pending, Confirmed, Completed
- Search by patient or doctor name

### 💰 Billing
- Invoice management with payment tracking
- Progress bar showing % collected
- Status: Paid, Partial, Pending
- Automatic status calculation

### 🧾 Receipts
- Professional PDF receipt generation
- Patient info + billing summary
- Native Android Print dialog (save as PDF)
- Hospital branding with logo

---

## 🏗️ Project Structure

```
RijongMediCore/
├── .github/
│   └── workflows/
│       └── build.yml          ← GitHub Actions: auto-builds APK on push
├── app/
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── assets/www/
│       │   └── index.html     ← The entire app (HTML/CSS/JS)
│       ├── java/com/medicore/hms/
│       │   └── MainActivity.java  ← WebView wrapper + Print bridge
│       └── res/
│           ├── mipmap-*/      ← App icons (R in shield, all densities)
│           ├── values/
│           │   ├── strings.xml
│           │   └── styles.xml
│           └── xml/
│               └── file_paths.xml
├── gradle/wrapper/
│   └── gradle-wrapper.properties
├── build.gradle
├── settings.gradle
├── gradle.properties
└── gradlew / gradlew.bat      ← Generated on first build
```

---

## 🚀 Building the APK

### Option A — GitHub Actions (Recommended, no PC needed)

1. Upload this entire project to a GitHub repository
2. Push to `main` branch
3. Go to **Actions** tab → watch the build run (~2 minutes)
4. Download the **RijongMediCore-APK** artifact from the completed run
5. Extract the ZIP → install `app-debug.apk` on your phone

### Option B — Android Studio (Requires PC)

1. Open Android Studio
2. **File → Open** → select the `RijongMediCore` folder
3. Wait for Gradle sync to complete
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
5. Find APK in `app/build/outputs/apk/debug/`

### Option C — Command Line

```bash
chmod +x gradlew
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

---

## 📲 Installing on Android

1. Download the APK to your phone
2. Open **Settings → Security** (or Privacy)
3. Enable **Install from Unknown Sources** (allow your browser/files app)
4. Tap the APK file → Install

**Default PIN: `1234`** — change it after first login.

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Android wrapper | Java + WebView (minSdk 24 / Android 7+) |
| App UI | HTML5 + CSS3 + Vanilla JavaScript (ES5) |
| Print/PDF | Android PrintManager via JavascriptInterface |
| Data storage | In-memory JS arrays + localStorage for PIN |
| Build system | Gradle 8.4 + Android Gradle Plugin 8.2.2 |
| CI/CD | GitHub Actions |

---

## 📦 Package Info

- **Package ID:** `com.rijong.medicore`
- **Min SDK:** 24 (Android 7.0+)
- **Target SDK:** 34 (Android 14)
- **Version:** 7.0.0

---

*Developed with ❤️ for Rijong MediCore Hospital*
